# BU MET CS789 Final Project
Brian Tran
btran89@bu.edu
U53262859

## Instructions
1) Double click "CryptographyApp.exe" in the same directory.
2) The program should run.
3) Enjoy!

## To see the project
- Open the solution Visual Studio located in "CS789CryptographyProgram/CS789CryptographyProgram.sln" and open "AlgorithmManager.cs"
- If you cannot open the solution, simply review the AlgorithmManager.cs ; in "CS789CryptographyProgram/CryptographyBusiness/AlgorithmManager.cs"

## Conclusion
Please e-mail me at btran89@bu.edu if you have any questions.